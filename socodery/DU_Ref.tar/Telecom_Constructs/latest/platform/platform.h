#ifndef PLATFORM_H
#define PLATFORM_H

extern ReturnType initializeplatform();

#endif
