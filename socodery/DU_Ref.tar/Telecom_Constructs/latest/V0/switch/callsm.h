/*
Call Manager header file
*/

#ifndef CALL_SM_H
#define CALL_SM_H

#include "basictypes.h"

extern ReturnType handleoriginatingcall(CommPoint origpcommpointid);

#endif
