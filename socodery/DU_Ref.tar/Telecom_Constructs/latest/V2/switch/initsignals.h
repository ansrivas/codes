/*
prototpye for the signal handler init.
*/
#ifndef SIGNAL_INIT_H
#define SIGNAL_INIT_H

#include"basictypes.h"

extern returntype initializesignalhandlers();

#endif
