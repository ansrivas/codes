/*
Call Manager header file
*/

#ifndef CALL_SM_H
#define CALL_SM_H

extern void * handleoriginatingcall(void * origpsockid);

extern void initializecalltable();

#endif
