#include<stdio.h>
#include<netinet/in.h>
main()
{
  char *ptr;
  char  arry[4];
  int * pint;
  int val1,val2;
  int i;
  val1 = 0x12345670;
  val2 = 0x89abcdef;

  pint = (int *)arry;
  *pint = 0x12345670;

  ptr = (char *)&val1;
  printf("size of pointer is  %x bytes",sizeof(ptr));
  printf("\nVal of val1 is  %x ",val1);
  printf("\nVal of val2 is  %x \n",val2);

  printf("Val of Ptr is %x : %u\n",*ptr, ptr);
  for(i=0;i<3;i++)
  {
    ptr++;
    printf("Val of Ptr is %x : %u\n",*ptr, ptr);
  }
  val2=htonl(*pint);
  ptr = (char *)&val2;
  i = 0;
  printf("Val of Ptr is %x : %u : %u : %x\n",*ptr, ptr, &arry[i], arry[i]);
  for(i=1;i<4;i++)
  {
    ptr++;
    printf("Val of Ptr is %x : %u : %u : %x\n",*ptr, ptr, &arry[i], arry[i]);
  }
}
