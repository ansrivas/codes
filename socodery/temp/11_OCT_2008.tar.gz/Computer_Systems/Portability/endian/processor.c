#include<stdio.h>
#include<sys/types.h>

/* If executed on 10.203.161.9 it will work fine as it is 32-bit and on 10.203.161.7 it will work fine if the comments are removed as it is 64-bit.*/

main(int argc, char *argv[])
  {
        unsigned int *ptr,i;
  //    long i;
        ptr=&argc;
        i=(unsigned int )ptr;
   //   i=(long )ptr;
        printf("The Value of argc  is %d\n",*((unsigned int *)i));

  }
