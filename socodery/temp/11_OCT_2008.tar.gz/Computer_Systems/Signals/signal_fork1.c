#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>


int parent ();
int cpid, ppid, num = 0;

main ()
{
  int i, status;
  ppid = getpid ();		/*parent's id. */
  signal (SIGINT, &parent);
  if ((cpid = fork ()) != 0)
    {
      wait (&status);		/*wait for the child to terminate */
      printf ("parent exit %d %d\n", WEXITSTATUS (status), num);
    }
else
{				/*child */
  printf ("in child\n");
  for (i = 0; i < 10; i++)
    {
      kill (ppid, SIGINT);	/*send signal to the parent */
      sleep (1);
    }
  exit (40);
}
}

parent ()
{
  signal (SIGINT, &parent);
  printf ("in parent signal\n");
  num++;
}
