/*
A simple program having two threads
threads do not have contention as they are not sharing any global variables
startThread1 is the entry point function of one thread
startThread2 is the entry point function of the other thread
*/

#include <unistd.h>
#include <stdio.h>
#include <pthread.h>


/*
startThread1 takes an input through thread creation and prints it after properly typecasting it
*/

void * startthread1(void * thr_p) 
{
	int i = 0;
	int pinput = *((int *) thr_p);
	while (i++ < 20) {
		printf("first thread %d %d\n", pthread_self(), i);
		sleep(1);
	}
	return ((void *) NULL);
}

/*
startThread2 prints the thread id and the value of a local variable i in a loop
*/

void * startthread2(void * thr_p) {
	int i = 1000;
	while (i-- > 980) {
		printf("second thread %d: %d\n", pthread_self(), i);
		sleep(1);
	}
	return ((void *) NULL);
}

/*
main creates two threads and waits for them to exit
threads have system scope
one of the threads is passed the address of a local variable defined in main whereas the other one is given a NULL parameter
*/


int main()
{
	int retval;
	int thread1input = 10;
	pthread_t m_ThreadId;
	pthread_t l_ThreadId;
	pthread_attr_t atrr;
	pthread_attr_init(&atrr); // initialize attr with default attributes
	pthread_attr_setscope(&atrr, PTHREAD_SCOPE_SYSTEM);

	retval = pthread_create(&l_ThreadId, &atrr, startthread1, (void *)(&thread1input));
	if (0 != retval)
	{
		printf("thread creation failed\n");
		return (-1);
	}
	retval = pthread_create(&m_ThreadId, NULL, startthread2, (void *)NULL);
	if (0 != retval)
	{
		printf("thread creation failed\n");
		return (-1);
	}

	retval = pthread_join(l_ThreadId, NULL);
	if (0 != retval)
	{
		printf("thread join failed\n");
		return (-1);
	}
	retval = pthread_join(m_ThreadId, NULL);
	if (0 != retval)
	{
		printf("thread join failed\n");
		return (-1);
	}
	return 0;
}
