#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<unistd.h>

main() {
	pid_t pid    = 0;
	int counter  = 0;
	int retval   = 0;
	int status   = 0;
	printf("process id: %u, parent process id: %u\n", getpid(), getppid());
	sleep (10);
	{
		pid = fork();
		if (0 == pid)
		{
			printf("child process \n");
			int fd = open("x", O_CREAT|O_RDWR, S_IRWXU);
			close(1);
			dup(fd);
			printf("child process \n");
       		     execlp("childprogram", "childprogram", NULL);
		}
       		 else
       		 {
			retval = wait(&status);	
			printf("parent process \n");
       		 }
	}
}
