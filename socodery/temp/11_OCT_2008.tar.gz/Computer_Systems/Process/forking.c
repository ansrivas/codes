#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>

int main()
{
	printf("L0");
	printf("L1\n");
	fork();
	printf("L2");
	printf("Bye\n");
        return 1;
}
