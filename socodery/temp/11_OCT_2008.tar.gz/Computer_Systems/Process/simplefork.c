#include<stdio.h>
#include<unistd.h>

main ()
{
  int i;
  i = 10;
  if (fork () != 0)
    {
      printf ("\nfor Parent ppid =%d and pid =%d\n", getppid (), getpid ());
      i += 20;
      printf ("\n%d", i);
    }
  else
    {
      printf ("\nfor child ppid =%d and pid =%d\n", getppid (), getpid ());
      i += 40;
      printf ("\n%d", i);
    }
}
