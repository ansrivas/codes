#include<stdio.h>
#include<unistd.h>

int main()
{
	printf("parent program running \n");
	sleep(2);
	execlp("./child", "child", NULL);
	return 2;
}
