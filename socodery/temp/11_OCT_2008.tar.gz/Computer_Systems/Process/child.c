#include<stdio.h>
#include<unistd.h>

int main()
{
	printf("child program running \n");
	write(1, "child program running \n", 15);
	sleep(2);
	write(3, "writing in the file", 15);

//	execlp("./parent", "parent", NULL);
	return 2;
}
