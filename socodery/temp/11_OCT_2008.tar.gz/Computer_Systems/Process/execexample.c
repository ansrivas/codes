#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
main()
{
int pid;
pid =fork();
if(pid==0)
{
	printf("\nexec starts");
	execl("/bin/ls","ls","-l",(char *)0);
	printf("exit");
}
else
{
	wait(0);
	printf("parent\n");
}
}
