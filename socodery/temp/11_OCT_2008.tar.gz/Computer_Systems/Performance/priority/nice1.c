#include<stdio.h>
#include<errno.h>
#include<sys/resource.h>
#include<signal.h>
void Int_handler(int signo)
  {
     printf("\nTerminating Process\n");
     exit(0);
  }  

main()
  {
    int pid,retnice;
      
    printf("\npress ^C to stop process");
    pid =fork();
   
    for(;;)
      {
        if(pid == 0)
           {
             
    signal(SIGINT,Int_handler);
            errno=0;
            retnice =nice(-5);
            if(retnice ==-1)
              {
               printf("\nchild gets the highest CPU Priority %d\n",retnice);
               printf("\n%d the error is %d\n",errno);
               perror(" ");
              }
               sleep(1);
           }
        else
          { 
            retnice=nice(4);
            printf("\nParent gets lower CPU Priority %d\n",retnice);
            sleep(1);
          }
      }
  }
 
