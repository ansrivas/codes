#include <sys/types.h>
#include <sys/stat.h>

#define MAX_FILE_SIZE 256

int main()
{
    struct stat localstat;
    char filename[MAX_FILE_SIZE];
    memset(filename, '\0', 256);
    scanf("%s", filename);
    stat(filename, &localstat);
    printf("file size %d\n", localstat.st_size);
    return 1;
}

