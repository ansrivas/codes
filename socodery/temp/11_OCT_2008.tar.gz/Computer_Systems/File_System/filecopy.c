#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<unistd.h>


main()
{
char c;
int in , out;
in =open("sample",O_RDONLY);
//out=open("stat2.c",O_CREAT | O_WRONLY,S_IRUSR|S_IWUSR);
out=open("stat3.c",O_RDWR|O_CREAT|O_TRUNC,S_IRWXU);
//while(read(in,&c,1)==1)
while(read(in,&c,1)!=0)
write(out,&c,1);
close(in);
close(out);
} 
