#include<stdio.h>
main()
{       unlink("stat6.c");
	if((unlink("stat4.c"))==-1)
	{perror("error");
		exit(1);
	}
	exit(0);
};
