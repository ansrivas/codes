
/*This program illustrates how stat funtion is used */
#include<stdio.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>
main()
{
	struct stat sbuf;
	char filename[100];
	printf("\nenter the filename:");
	gets(filename);
	stat(filename,&sbuf);
	if (S_ISREG(sbuf.st_mode))
		printf("%s is a regular file",filename);
	else
		printf("%s is not a regular file",filename);
}
