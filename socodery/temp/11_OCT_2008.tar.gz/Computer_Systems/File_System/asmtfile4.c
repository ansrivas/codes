#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>

int main()
{
    int fd1,fd2;
    char str1[20],str2[20];
    int length1,length2,choice,length;
    fd1=open("open1.dat",O_CREAT|O_RDWR|O_TRUNC,0777);
    fd2=open("open2.dat",O_CREAT|O_RDWR|O_TRUNC|O_APPEND,0777);

    printf("\n\tEnter input  for open1.dat file\n");
    scanf("%[^\n]s",str1);
    length1=strlen(str1);
    printf("\n\tEnter input for open2.dat file\n");
    getchar();
    scanf("%[^\n]s",str2);
    length2=strlen(str2);
    if(fd1!=-1 && fd2!=-1)
      {
             printf("\n\tFile open1.dat and open2.dat is opened for Write operation");
             write(fd1,str1,length1);
             write(fd2,str2,length2);
             close(fd1);
             close(fd2);
      }
      
             do
             {
                  printf("\n\t1.Beginning");
                  printf("\n\t2.Middle");
                  printf("\n\t3.End");
                  printf("\n\t4.Exit");

                  printf("\n\tEnter your choice for doing write operation where ever in the file\n");
                  getchar();
                  scanf("%d",&choice);
                  switch(choice)
                  {
                        case 1: 
                              fd2=open("open2.dat",O_RDWR); 
                              printf("\n\tEnter input\n");
                              getchar();
                              scanf("%s",str1);
                              length=strlen(str1);
                              lseek(fd2,0L,SEEK_SET); 
                              write(fd2,str1,length);
                              break;

                        case 2:
 
                              fd2=open("open2.dat",O_RDWR); 
                              printf("\n\tEnter input\n");
                              getchar();
                              scanf("%s",str1);
                              length=strlen(str1);
                              lseek(fd2,5,1);
                              write(fd2,str1,length);
                              break;
                       case 3:

                              fd2=open("open2.dat",O_RDWR); 
                              printf("\n\tEnter input\n");
                              getchar();
                              scanf("%s",str1);
                              length=strlen(str1);
                              lseek(fd2,0L,2);
                              write(fd2,str1,length);
                              break;
                       case 4:
                                break;
                   }
            }  while(choice!=4);

  close(fd1);
  close(fd2);
  return 0;
}
