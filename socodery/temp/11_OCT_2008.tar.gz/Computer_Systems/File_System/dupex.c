#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

static char *str1 = "12345";
static char *str2 = "678";

int main()
{
  int f1, f2;
  

  f1 = open ("mytmp", O_RDWR | O_CREAT, 0700);
  f2 = dup(f1);

  write(f1, str1, strlen(str1));
  write(f2, str2, strlen(str2));

  return 0;
}
