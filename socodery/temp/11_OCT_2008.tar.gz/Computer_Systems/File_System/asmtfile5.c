#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>

main()
  {
     int fd,nobytes;
     char *buff;
     fd =open("input.txt",O_RDWR);
     lseek(fd,10,SEEK_SET);
     while(1)
      {
        nobytes=read(fd,&buff,5);
        write(STDOUT_FILENO,&buff,nobytes);
      }  

  }   
