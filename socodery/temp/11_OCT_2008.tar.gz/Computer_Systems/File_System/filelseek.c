
/*This program demonstrates the lseek system call */
#include<stdio.h>
#include<sys/types.h>
#include<fcntl.h>
#include<sys/stat.h>
main()
{
	int fd;
	long int position;
	fd =open("stat1.c",O_RDONLY);
	if(fd !=-1)
	{
		position=lseek(fd,28L,0);
               printf("\n%d",position);
		if(position!=-1)
			printf("\nthe length of stat1.c is %ld\n",position);
		else
			perror("lseek error");
	}
	else
		printf("\ncan't open stat1.c");
}


