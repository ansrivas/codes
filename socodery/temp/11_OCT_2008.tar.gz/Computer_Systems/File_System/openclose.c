#define SIZE 10
int main(int argc,char *argv[])
{
  int fd;
  char buff[SIZE];
  int n;
  if(argc!=2)
   {
     printf("Usage:%s filename\n",argv[0]);
     exit(1);
   }
  if(fd=open(argv[1],0)==-1)
   {
     perror(argv[0]);
     exit(1);
   }
  while((n=read(fd,buff,SIZE))>0)
  write(1,buff,n);
  close(fd);
 }
