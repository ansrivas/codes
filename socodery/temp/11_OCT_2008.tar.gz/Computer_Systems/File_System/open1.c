/* Example to demonstrate for open system call */

#include<stdio.h>
#include<sys/types.h>		/*define types used by sys/stat.h */
#include<sys/stat.h>
#include<fcntl.h>

static char message[] = "Good morning";
main ()
{
  int fd;
  char buffer[80];

  /* open a.txt for read/write access   (O_RDWR)
     create a.txt if it does not exist  (O_CREAT)
     return error if a.txt already exists   (O_EXCL)
     permit read/write access to file  (S_IRWXU) */

  fd = open ("a.txt", O_RDWR);
	if (fd != -1)
  	 {
           printf ("\nfile opened for read/write access\n");
           write (fd, message, sizeof (message));

           lseek (fd, 0, SEEK_SET);		/* go to beginning of file */


        if (read (fd, message, sizeof (message)) == sizeof (message))
             printf ("\n%s was written to data file\n", buffer);
        else
             printf ("\nerror reading file\n");
   close (fd);
          }

       else
          printf ("\nFile already exists\n");
          exit (0);
}
