#include <stdio.h>

int main()
{
	printf("I am writing on the screen\n");
	printf("I am writing on the screen\n");
	printf("I am writing on the screen\n");
	printf("I am writing on the screen\n");
	printf("I am writing on the screen\n");
	return 1;
}
