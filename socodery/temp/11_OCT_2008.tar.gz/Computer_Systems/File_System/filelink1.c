main()
{
link("soma","shalu");
}
