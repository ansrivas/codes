/*Program to demonstrate how to create File */

#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
main ()
{
  int fd,fd1;
  fd = creat ("datafile.dat", S_IREAD | S_IWRITE);
  fd1=open("datafile1.dat",O_CREAT|O_WRONLY,0777);
  if (fd == -1)
    printf ("\nerror in opening file");
  else
    printf ("\ndatafile created for read and write and is currently empty\n");
   
   if (fd1 == -1)
     printf ("\nerror in opening file");
   else
     printf ("\ndatafile created for read and write and is currently empty\n");

  close (fd);
  close(fd1);
  exit (0);
}
