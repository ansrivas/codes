#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

FILE * fp = NULL;

int writefunction()
{
	int    fd;
	int    retval;
	char   writebuffer[32];
	int    lcounter = 0;
	size_t buffsize = 31;

	retval = mkfifo("abcfile", S_IRWXU);
	if(-1 == retval)
        {
		printf("FIFO CREATION ERROR\n");
		if(EEXIST==errno)
		{
			printf("FIFO ALREADY Exists\n");
                }
		else
			exit(-1);
        }

//	fd = open("abcfile", O_WRONLY);
	fd = open("abcfile", O_RDWR);
	while (lcounter++ < 16)
	{
		printf("please enter the next string to send to the reader\n");
		buffsize = read(0, writebuffer, buffsize);
		if (buffsize > 0)
		{
			write(fd, writebuffer, buffsize);
		}
		buffsize = 31;
		buffsize = read(fd, readbuffer, buffsize);
		buffsize = write(fd, readbuffer, buffsize);
		buffsize = 31;
	}
	close(fd);
	return;
}

int main ()
{
	printf("I am the writer program\n");
	writefunction();
	printf("I am done with writing\n");
	return 1;
}
