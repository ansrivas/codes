#include<stdio.h>
#include<stdlib.h>

        main(int argc,char *v[])
        {
        long int x,i,y=50;
        char a[2]="12";
//      x=atoi(a);
        printf("x=%d\n",atoi(a));
        }

