#ifndef MEM_LIB_H
#define MEM_LIB_H

extern char * mymalloc(int);
extern void   myfree(char *);

#endif
