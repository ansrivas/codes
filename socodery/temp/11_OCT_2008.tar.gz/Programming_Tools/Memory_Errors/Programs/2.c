/******************************************************************************
****Illegal read/write

Illegal read/write errors occurs when you try to read/write from/to an address that is not in the address range of your program. 
******************************************************************************/

#include <stdlib.h>
int main()
{
        int *p, i, a;
        p = malloc(10*sizeof(int));
        p[11] = 1;                /* invalid write error */
        a = p[11];                /* invalid read error */
                free(p);
        return 0;
}



