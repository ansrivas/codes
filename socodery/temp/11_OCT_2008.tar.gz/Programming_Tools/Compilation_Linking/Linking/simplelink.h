/*Header File*/
 int gsimple;
 int gcomplex;
extern int complexlink(int lflag);
extern int simplelink(int lflag);

