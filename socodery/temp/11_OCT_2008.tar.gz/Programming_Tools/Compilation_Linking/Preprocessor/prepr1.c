#include <stdio.h>

int main()
{
     printf("What should happen with the #include statement?");
     return 0;
}

