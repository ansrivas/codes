#define MAX(A,B) ((A) > (B) ? (A) : (B))

int main()
{
     printf ("%d",MAX(7*3523, 8*1425));
     return 0;
}

