//#include <stdio.h>
#define TRUE 1

int main()
{
#if TRUE
   printf ("TRUE");
#else
   printf ("FALSE");
#endif
   return 0;
}

