#define PRINT_STRING(x) printf(x)

int main()
{
    PRINT_STRING("Calling macros to print a string");
    return 0;
}

