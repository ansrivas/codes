gcc -c simplelink.c
gcc -c program.c
gcc -o program program.o simplelink.o

