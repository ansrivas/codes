double mean(double,double);
