extern int gsimple;
extern int simplelink(int lflag);
extern int anotherfunction(int lflag);

