extern int gcomplex;
extern int complexlink(int lflag);

