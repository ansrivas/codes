#include<stdio.h>
#include<math.h>
int main()
{
 int flag;
 if(flag==sqrt(2))
  printf("\nHello\n");
 else
  printf("\nHi\n");
 return 0;
}
