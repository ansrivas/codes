# Syntax:
# expr op1 math-operator op2

#clear
x=10
expr 1 + 3
expr 2 - 1
expr 10 / 2
expr 20 % 3
expr 10 \* 3
echo `expr 6 + 3`
echo "expr 6 + 3"
echo 'Value:$x'
echo "Value:$x"
