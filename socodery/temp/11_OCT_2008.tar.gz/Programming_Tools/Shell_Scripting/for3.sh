clear
for ((  i = 0 ;  i <= 5;  i++  ))
do
  echo "Welcome $i times"
done
