#
# My first shell script
#
clear
echo "PRISM"
