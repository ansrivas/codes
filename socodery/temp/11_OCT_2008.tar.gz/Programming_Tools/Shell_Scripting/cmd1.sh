
ls /bin/[a-c]* ;date;who

#date who
