clear
no=10.5
No=20
NO = 30;
v1=
v2=""
echo $no
echo $No
echo $NO
echo $v1
echo $v2

