clear
ls foo
cp y y.bak
mv y.bak y.okay
tail -10 myfile
mail raj
sort -r -n myfile
date
ls grate_stories_of

