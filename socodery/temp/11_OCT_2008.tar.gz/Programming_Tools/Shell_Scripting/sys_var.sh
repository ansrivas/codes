clear
echo $USERNAME
echo $HOME
echo $COLUMNS
echo $BASH
echo $BASH_VERSION
echo $LINES
echo $LOGNAME
echo $OSTYPE
echo $PATH
echo $PS1
echo $PWD
echo $SHELL
echo $USERNAME
