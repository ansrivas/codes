extern void link_file()
{
    printf("This function is just called to link this file\n ");
    return;
}

