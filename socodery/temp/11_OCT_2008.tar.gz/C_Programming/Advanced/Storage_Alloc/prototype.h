/*************************************************************************
*
*  FILE NAME    : prototype.h
*
*  DESCRIPTION  : Header file for prorgam to demonstrate storage allocation
*
*  DATE    NAME    REFERENCE          REASON
*
*  8-MAR-08  Sibu    C FG 1.0           Initial creation
*
*  Copyright 2008, Aricent Technologies (Holdings) Ltd
*
**************************************************************************/
extern int a1;

extern void next(void);
extern void next1(void);
