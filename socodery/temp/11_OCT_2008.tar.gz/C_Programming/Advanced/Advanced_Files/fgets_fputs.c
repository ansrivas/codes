/*************************************************************************
*
*  FILE NAME    : fgets_fputs.c
*
*  DESCRIPTION  : Demosntration of fgets and fputs
*
*  DATE    NAME    REFERENCE          REASON
*
*  8-MAR-08  Sibu    C FG 1.0           Initial creation
*
*  Copyright 2008, Aricent Technologies (Holdings) Ltd
*
**************************************************************************/
/*************************************************************************
*               HEADER FILES
*************************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  FILE *fp;
  char str[81];

  if((fp = fopen("test1.txt", "r"))==NULL) 
  {
    printf("Cannot open file.\n");
    exit(EXIT_FAILURE);
  }

  while(!feof(fp)) 
  {
    fgets(str, 80, fp);
    printf("%s", str);
//    getchar();
  }

  fclose(fp);

  return EXIT_SUCCESS;
}













