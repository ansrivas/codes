/*************************************************************************
*
*  FILE NAME    : fprintf_fscanf.c
*
*  DESCRIPTION  : Demonstration of fscanf and fprintf
*
*  DATE    NAME    REFERENCE          REASON
*
*  8-MAR-08  Sibu    C FG 1.0           Initial creation
*
*  Copyright 2008, Aricent Technologies (Holdings) Ltd
*
**************************************************************************/
/*************************************************************************
*               HEADER FILES
*************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
  FILE *fp;
  double ld;
  int d;
  int count;
  char str[80];


  if((fp = fopen("sample", "w"))==NULL) 
  {
    printf("Cannot open file.\n");
    exit(EXIT_FAILURE);
  }

  fprintf(fp, "%f %d %s", 345.342, 908, "hiiiiiiii");
  fclose(fp);

  if((fp = fopen("sample", "r"))==NULL) 
  {
    printf("Cannot open file.\n");
    exit(EXIT_FAILURE);
  }

  count = fscanf(fp, "%lf%d%s", &ld, &d, str);
  printf("%f %d %s %d\n", ld, d, str,count);
  count = fscanf(fp, "%d", &d);
  fprintf(stdout,"%d %d\n", d,count);
  fclose(fp);

  return EXIT_SUCCESS;
}











