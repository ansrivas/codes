struct s
{
  int a:4;
}s1;
main()
{
    fscanf(;

    printf("%d\n",s1.a);
}
