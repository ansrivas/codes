/*************************************************************************
*
*  FILE NAME    : macro_example.c
*
*  DESCRIPTION  : Program to demonstrate macros
*
*  DATE    NAME    REFERENCE          REASON
*
*  8-MAR-08  Sibu    C FG 1.0           Initial creation
*
*  Copyright 2008, Aricent Technologies (Holdings) Ltd
*
**************************************************************************/

#include <stdio.h>

#define STRING1          "A macro definition\n"
#define STRING2          "must be all on one line!\n"
#define EXPRESSION1      1 + 2 + 3 + 4
#define EXPRESSION2      EXPRESSION1 + 10
#define ABS(x)           ((x) < 0) ? -(x) : (x)
#define MAX(a,b)         (a < b) ?  (b) : (a)
#define BIGGEST(a,b,c)   (MAX(a,b) < c) ?  (c) : (MAX(a,b))

int main ()
{
  printf (STRING1);
  printf (STRING2);
  printf ("%d\n", EXPRESSION1);
  printf ("%d\n", EXPRESSION2);
  printf ("%d\n", ABS(-5));
  printf ("Biggest of 1, 2, and 3 is %d\n", BIGGEST(1,2,3));

  return 0;
}


