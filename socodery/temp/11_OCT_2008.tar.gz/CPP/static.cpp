#include<iostream>

using namespace std;

class temp
{
public:
int x;
static void display()
{
cout << "in display"<< endl;
}
};

int main()
{
temp A;
A.display();
temp::display();
return 0;
}
