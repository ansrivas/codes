#inlcude<stdio.h>
int main()
	{
		int sum=0;
		int i;
		printf("\nEnter the no");
		scanf("%d",&n);

		for(i=0;i<n;i++)
		{
			sum+=i;
		}
	
printf("%d",1/0);

}
