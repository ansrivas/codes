int main()
{
printf("%d",sizeof(int*));
return 0;
}
