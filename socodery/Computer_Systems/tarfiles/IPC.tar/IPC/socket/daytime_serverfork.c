#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/wait.h>
#include<signal.h>
void *sig_handler(int signo)
{
        pid_t pid;
        int stat;
        while((pid =waitpid(-1,&stat,WNOHANG))>0)
	{
		printf("Child caught\n");
	}
}
int main(int argc,char *argv[])
{
	int listenfd,connfd;
	struct sockaddr_in servaddr,cliaddr;
	socklen_t len;
	char buff[512];
	int x;
	signal(SIGCHLD,sig_handler);
	if(argc !=2)
	{
		printf("a.out portno");
	}
	listenfd = socket(AF_INET,SOCK_STREAM,0);
	if(listenfd ==-1)
	{
		perror("socket");
		exit(1);
	}
	else
	{
		printf("Socket created successfully\n");
	}

	bzero(&servaddr,sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(atoi(argv[1]));

	x = bind(listenfd,(struct sockaddr *)&servaddr,sizeof(servaddr));
	if(x ==-1)
	{
		perror("bind");
		exit(1);
	}
	else
	{
		printf("bind successfull\n");
	}

	x = listen(listenfd,10);
	if(x ==-1)
	{
		perror("listen");
		exit(1);
	}
	else
	{
		printf("Listen successfull\n");
	}	
	for(;;)
	{
		len = sizeof(cliaddr);
		memset(&cliaddr,0,sizeof(cliaddr));
		connfd = accept(listenfd,(struct sockaddr *)&cliaddr,&len);
		if(connfd ==-1)
		{	
			perror("accept");
			exit(1);
		}
		else
		{
			printf("accept successfull\n");
		}
//		printf("Connection request from %s\n",inet_ntoa(cliaddr.sin_addr));
		if(fork()==0)
		{
			read(connfd,buff,sizeof(buff));
			write(1,buff,strlen(buff));
			strcpy(buff,"Programming");
			write(connfd,buff,strlen(buff));
			close(connfd);
		}
		else
		{
			close(connfd);
		}
}
shutdown(listenfd,SHUT_RDWR);
close(listenfd);
}
