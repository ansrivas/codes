/*this program demonstrates that the changes done to local variables is not shared between parent and child process*/

#include<stdio.h>
#include<unistd.h>

int main ()
{
  int i;
  i = 10;
  if (fork () != 0)
    {
      while (1)
      {
          printf ("\nfor Parent ppid =%d and pid =%d\n", getppid (), getpid ());
          i += 20;
          printf ("\n%d", i);
	  sleep(5);
      }
    }
  else
    {
      while (1)
      {
          printf ("\nfor child ppid =%d and pid =%d\n", getppid (), getpid ());
          i += 40;
          printf ("\n%d", i);
	  sleep(5);
      }
    }
return 0;
}
