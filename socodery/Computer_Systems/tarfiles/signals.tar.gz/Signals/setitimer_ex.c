#include<signal.h>
#include<sys/time.h>

#define INTERVAL 5

int x = 0;

void alarm_handler (int i)
{
   struct itimerval time_val;


   x += INTERVAL;
   
   printf("\n%d sec up , time up\n",x);
   time_val.it_interval.tv_sec = 0;
   time_val.it_interval.tv_usec = 0;
   time_val.it_value.tv_sec = INTERVAL; /* 5 seconds timer */
   time_val.it_value.tv_usec = 0;
   
   setitimer(ITIMER_REAL, &time_val,0);
   
}

void exit_func (int i)
{
    printf("\nctrl C caught\n");
    exit(0);
}

int main ()
{
  struct itimerval time_val;
  
  time_val.it_interval.tv_sec = 10;
  time_val.it_interval.tv_usec = 0;
  time_val.it_value.tv_sec = INTERVAL; /* 5 seconds timer */
  time_val.it_value.tv_usec = 0;

  signal(SIGALRM,alarm_handler); /* Catch the Alarm signal */
  signal(SIGINT,exit_func);
  
  setitimer(ITIMER_REAL, &time_val,0);
  while (1)
  {
	sleep(1);
    //printf("!");
  }
  
  return 0;

}

