/*
This program shows how a signal handler is installed and when it is invoked.
It is invoked when another program sends a signal to this program. 
After the signal has been sent by another program, OS runs the signal handler for the target program when the target program gets the CPU(i.e., is scheduled on the CPU and returning from the kernel mode)
It also shows that signal handlers can't be installed for all types of signals especially SIGKILL.
SIGKILL is a signal which can't be caught and handled, otherwise program may misuse it so that it can't be killed.
*/

#include<stdio.h>
#include<signal.h>
#include<errno.h>

void signal_handler(int signum)
{
	printf("signal_handler for signal : %d invoked\n", signum);
}


main()
{
	int sigret = 0;
	signal(SIGINT,signal_handler);
    	if (errno != 0) 
	{
		printf("SIGINT set error %d \n", errno);
	}
	signal(SIGHUP,signal_handler);
	if (errno != 0) 
	{
		printf("SIGHUP set error %d \n", errno);
	}
	signal(SIGKILL,signal_handler);
	if (errno != 0) 
	{
		printf("SIGKILL set error %d \n", errno);
	}
	while(1) 
	{
		sleep(5);
		printf("signal demo: while loop \n");
	}
	printf("can't print this \n");
}
